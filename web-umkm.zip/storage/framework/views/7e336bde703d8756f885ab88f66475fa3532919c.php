<?php
$website = DB::table('websites')->get();
?>

<?php $__env->startSection('content'); ?>
    <div class="authentication-inner col-lg-6 col-12">
        <!-- Register -->
        <div class="card">
            <div class="card-body">
                <!-- Logo -->
                <div class="app-brand justify-content-center">
                    <a href="index.html" class="app-brand-link gap-2">
                        <span class="app-brand-logo demo">

                            <img src="\img\favicon\icon.svg" alt="">

                        </span>
                        <span class="app-brand-text demo text-body fw-bolder"><?php echo e($website[0]->sitename); ?></span>
                    </a>
                </div>
                <h4 class="mb-2">Lupa Password? 🔒</h4>
                <p class="mb-4">Masukkan email anda yang telah terdaftar dan kami akan mengirim anda intruksi untuk
                    mereset
                    password</p>
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <form id="formAuthentication" class="mb-3" action="<?php echo e(route('password.email')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input id="email" type="email" class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="email" name="email" placeholder="Enter your email" autofocus=""
                            value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button class="btn btn-primary d-grid w-100">Kirim Reset Link</button>
                </form>
                <div class="text-center">
                    <a href="/login" class="d-flex align-items-center justify-content-center">
                        <i class="bx bx-chevron-left scaleX-n1-rtl bx-sm"></i>
                        Kembali Sign in
                    </a>
                </div>
            </div>
        </div>
        <!-- /Register -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webx\web-umkm\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>