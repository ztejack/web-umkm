

<?php $__env->startSection('content'); ?>
    <main id="main" class="h-100">
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="container h-100">
                <ol>
                    <li><a href="/">Home</a></li>
                    <li><a href="/koperasi/<?php echo e($jasaKoperasi->koperasi->id); ?>">Koperasi</a></li>
                    <li>Layanan</li>
                </ol>
                <h2><?php echo e($jasaKoperasi->koperasi->name); ?></h2>
                <section id="identity" class="identity mt-0">
                    <div class="container">
                        <div class="row detail-prd">
                            <div class="col-4 position-relative">
                                <div class="position-absolute top-50 translate-middle-img">
                                    <div class="image-identity">
                                        <?php if($jasaKoperasi->image): ?>
                                            <img src="<?php echo e(asset('storage/' . $jasaKoperasi->image)); ?>" alt="user-avatar"
                                                class="img-fluid" id="uploadedAvatar">
                                        <?php else: ?>
                                            <img src="/img/temp/product-temp.png" alt="user-avatar" class="img-fluid"
                                                id="uploadedAvatar">
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="describ col-8">
                                <h2><?php echo e($jasaKoperasi->name); ?></h2>

                                <div class="row">
                                    <span class="col-4"><i class="bx bx-chart"></i> Layanan <span
                                            class="val"><?php echo e($jasaKoperasi->service); ?></span>
                                    </span>
                                    <span class="col-4"><i class="bx bx-donate-heart"></i> Kebutuhan :
                                        <span class="val"><?php echo e($jasaKoperasi->needs); ?></span>
                                    </span>
                                </div>
                                <div class="row">
                                    <?php if($jasaKoperasi->where('isUnggulan')): ?>
                                        <span class="col-4">
                                            <span class="val-g">
                                                <i class="bx bxs-star bx-tada"></i> <strong>Layanan Unggulan</strong>
                                            </span>
                                        </span>
                                    <?php endif; ?>
                                    <span class="col-8">
                                        <i class="bi bi-telephone"></i>
                                        Hubungi Koperasi :
                                        <a href="tel:<?php echo e($jasaKoperasi->koperasi->user->phonenumber); ?>"
                                            class="val"><?php echo e($jasaKoperasi->koperasi->user->phonenumber); ?></a>

                                    </span>
                                </div>
                                <h6>Deskripsi Layanan</h6>
                                <p><?php echo $jasaKoperasi->description; ?> </p>
                            </div>
                        </div>
                    </div>
                    <section id="product" class="product">
                        <div class="row prod-container col-12">
                            <div class="row jdl p-0">
                                <div class="col-6 justify-conten-right">
                                    <h5>Layanan Lainnya</h5>
                                </div>
                            </div>
                            <?php $__currentLoopData = $jasaKoperasi->koperasi->jasa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-xl-3 col-md-6 d-flex align-items-stretch my-4 mt-xl-0 rounded"
                                    data-aos="zoom-in" data-aos-delay="100">

                                    <div class="product-card p-4">
                                        <?php if($service->image): ?>
                                            <img src="<?php echo e(asset('storage/' . $service->image)); ?>" alt="user-avatar"
                                                class="img-fluid" id="uploadedAvatar">
                                        <?php else: ?>
                                            <img src="/img/temp/service-temp.png" alt="user-avatar" class="img-fluid"
                                                id="uploadedAvatar">
                                        <?php endif; ?>
                                        <h4><?php echo e(Str::limit($service->name, 15, '...')); ?></h4>
                                        <div class="row">
                                            <span class="col-12 d-flex">
                                                <i class="bx bx-chart bx-burst my-auto"></i>
                                                &nbsp;
                                                <span class="my-auto"><?php echo e($service->service); ?></span>
                                            </span>
                                            <span class="col-12 d-flex">
                                                <i class="bx bx-donate-heart bx-burst my-auto"></i>
                                                &nbsp;
                                                <span class="my-auto"><?php echo e($service->needs); ?></span>
                                            </span>
                                            <a href="/koperasi/jasa/<?php echo e($service->slug); ?>"
                                                class="btn mt-3 col-12">Detail</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                </section>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webx\web-umkm\resources\views/pages/koperasi/jasa.blade.php ENDPATH**/ ?>