

<?php $__env->startSection('content'); ?>
    <main id="main">
        <section id="identity" class="identity">
            <div class="container">
                <div class="row">
                    <div class="col-4 position-relative">
                        <div class="position-absolute top-50 translate-middle-img">
                            <div class="image-identity">
                                <?php if($umkm->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $umkm->image)); ?>" alt="user-avatar" class="img-fluid"
                                        id="uploadedAvatar">
                                <?php else: ?>
                                    <img src="/img/temp/store-temp.png" alt="user-avatar" class="img-fluid"
                                        id="uploadedAvatar">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="describ col-8">
                        <h2><?php echo e($umkm->name); ?></h2>
                        <p><?php echo e($umkm->description); ?></p>
                        <div class="row">
                            <span class="col-4"><i class="bi bi-person"></i> Pemilik : <span
                                    class="val"><?php echo e($umkm->user->name); ?></span>
                            </span>
                            <span class="col-4"><i class="bi bi-telephone"></i> No HP :
                                <span class="val"><?php echo e($umkm->user->phonenumber); ?></span></span>
                        </div>
                        <div class="row">
                            <span class="col-4"><i class="bi bi-bag"></i> Product : <span
                                    class="val"><?php echo e($umkm->product->count()); ?></span>
                            </span>
                            <span class="col-4"><i class="bi bi-person-check"></i> Bergabung :
                                <span class="val"><?php echo e($umkm->created_at->diffForHumans()); ?></span>
                            </span>
                        </div>
                        <div class="row">
                            <span><i class="bi bi-geo-alt"></i> Alamat: <span
                                    class="val"><?php echo e($umkm->address); ?></span></span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="product" class="product">
            <?php if($umkm->product->count()): ?>
                <div class="container" data-aos="fade-up" data-aos-delay="200">
                    <div class="row">
                        <div class="row prod-container col-12">
                            <div class="row">
                                <div class="col-6 justify-conten-start">
                                    <h5>Product Unggulan</h5>
                                </div>

                            </div>
                            <?php if($umkm->product->where('isUnggulan')->count()): ?>
                                <?php $__currentLoopData = $umkm->product->where('isUnggulan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0"
                                        data-aos="zoom-in" data-aos-delay="100">
                                        <div class="product-card">
                                            <div class="icon"><i class="bx bxl-dribbble"></i></div>
                                            <h4><a href=""><?php echo e($product->name); ?></a></h4>
                                            <p>Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi
                                            </p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="col-12 m-4 d-flex">
                                    <h3 class="m-auto">UMKM ini Belum Memiliki Produk Unggulan :)</h3>
                                </div>
                            <?php endif; ?>

                        </div>
                        <div class="row prod-container col-12">
                            <div class="row jdl p-0">
                                <div class="col-6 justify-conten-right">
                                    <h5>Product Terbaru</h5>
                                </div>
                                
                            </div>
                            <?php $__currentLoopData = $umkm->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-xl-3 col-md-6 d-flex align-items-stretch my-4 mt-xl-0 rounded"
                                    data-aos="zoom-in" data-aos-delay="100">

                                    <div class="product-card p-4">
                                        <?php if($product->image): ?>
                                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="user-avatar"
                                                class="img-fluid" id="uploadedAvatar">
                                        <?php else: ?>
                                            <img src="/img/temp/product-temp.png" alt="user-avatar" class="img-fluid"
                                                id="uploadedAvatar">
                                        <?php endif; ?>
                                        <h4><?php echo e($product->name); ?></h4>
                                        <div class="row">
                                            <span class="col-12 d-flex">
                                                <i class="bx bx-money bx-burst my-auto"></i>
                                                &nbsp;Harga &nbsp;
                                                <span class="my-auto">: Rp. <?php echo number_format($product->price,0,',','.'); ?></span>
                                            </span>
                                            <span class="col-12 d-flex">
                                                <i class='bx bx-cuboid bx-burst my-auto'></i>
                                                &nbsp;Berat &nbsp;
                                                <span class="my-auto">: <?php echo e($product->weight); ?> Kg</span>
                                            </span>
                                            <span class="btn mt-3 col-12" data-bs-toggle="modal"
                                                data-bs-target="#exampleModal<?php echo e($product->id); ?>">Detail</span>
                                        </div>
                                    </div>
                                </div>
                                <?php echo $__env->make('components/modalProduct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>





                    </div>

                </div>
            <?php else: ?>
                <h1 class="text-center">Not Found :(</h1>
            <?php endif; ?>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webx\web-umkm\resources\views/pages/umkm.blade.php ENDPATH**/ ?>