<section id="jasa-card" class="">
    <div class="row py-3 mb-4">
        <div class="col-6">
            <h4 class="fw-bold">Layanan Unggulan <?php echo e($koperasi->name); ?> </h4>
        </div>

    </div>

    <?php if(session()->has('successUnggulan')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('successUnggulan')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <div class="row">
        <?php if($services->where('isUnggulan')->count()): ?>
            <?php $__currentLoopData = $services->where('isUnggulan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-3">
                    <div class="card h-100">
                        <div class="img-container img-container-prd card-img-top">
                            <?php if($service->image): ?>
                                <img class="" src="<?php echo e(asset('storage/' . $service->image)); ?>"
                                    alt="Card image cap">
                            <?php else: ?>
                                <img class="card-img-top img-fluid" src="/img/temp/service-temp.png"
                                    alt="Card image cap">
                            <?php endif; ?>
                        </div>

                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($service->name); ?></h5>
                            <h5 class="card-title">Layanan Name</h5>
                            <p class="card-text">
                                <span class="text-success">
                                    <i class="bx bx-layer"></i>
                                </span>
                                Layanan
                            </p>
                            <form action="/dashboard/koperasi-jasa/<?php echo e($service->id); ?>/unggulan" method="post">
                                <?php echo method_field('put'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" class="btn-check" id="btncheck2" value="0" name="isUnggulan"
                                    autocomplete="off">
                                <button class="btn btn-outline-primary" for="btncheck2"
                                    onclick="return confirm('Apa anda yakin?')"><i class='bx bxl-service-hunt'></i>
                                    Hilangkan
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <h4 class="text-center">Belum ada Layanan unggulan :)</h4>
        <?php endif; ?>
    </div>

</section>
<hr class="my-5">

<?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<section id="Layanan-table" class="">
    <div class="row py-3 mb-4">
        <div class="col-6">
            <h4 class="fw-bold">Tabel Layanan</h4>
        </div>
        <div class="col-6 d-flex ">
            <a class="ms-auto" href="/dashboard/koperasi/<?php echo e($koperasi->id); ?>/koperasi-jasa/create">
                <button type="button" class="btn btn-primary ">
                    <i class="tf-icons bx bx-plus d-lg-none "></i><span class="d-none d-sm-block"><i
                            class="tf-icons bx bx-plus"></i>&nbsp; Tambah Layanan</span>
                </button>
            </a>
        </div>
    </div>
    <div class="card">
        <h5 class="card-header">Tabel Layanan</h5>
        <form action="/dashboard/koperasi/<?php echo e($koperasi->id); ?>/koperasi-jasa" method="get" class="d-flex mx-4 mb-2">
            <input class="form-control me-2" type="text" name="search" id="search" placeholder="Search"
                aria-label="Search" value="<?php echo e(request('search')); ?>">
            <button class="btn btn-outline-primary" type="submit">Search</button>
        </form>
        <div class="table-responsive text-nowrap">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Foto</th>
                        <th>Nama</th>
                        <th>Layanan</th>
                        <th>Kebutuhan</th>
                        <th>Deskripsi</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php if($services->count()): ?>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($service->id); ?></td>
                                <td>
                                    <ul class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                        <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top"
                                            class="avatar avatar-xs pull-up img-container rounded" title=""
                                            data-bs-original-title="">
                                            <?php if($service->image): ?>
                                                <img src="<?php echo e(asset('storage/' . $service->image)); ?>" alt="Avatar"
                                                    class="img-fluid img-fi border-0t">
                                            <?php else: ?>
                                                <img src="/img/temp/service-temp.png" alt="Avatar"
                                                    class="img-fluid img-fit border-0">
                                            <?php endif; ?>
                                        </li>
                                    </ul>
                                </td>
                                <td>
                                    <span class="badge bg-label-primary me-1"><?php echo e($service->name); ?></span>
                                    <?php if($service->isUnggulan): ?>
                                        <span class="badge bg-label-danger me-1">Unggulan</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($service->service); ?></td>
                                <td><?php echo e($service->needs); ?></td>
                                <td><?php echo $service->description; ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                            data-bs-toggle="dropdown"><i
                                                class="bx bx-dots-vertical-rounded"></i></button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item"
                                                href="/dashboard/koperasi-jasa/<?php echo e($service->id); ?>/edit"><i
                                                    class="bx bx-edit-alt me-1"></i> Edit</a>
                                            <form id="userDelete-form"
                                                action="/dashboard/koperasi-jasa/<?php echo e($service->id); ?>"
                                                method="post">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="dropdown-item"
                                                    onclick="return confirm('Apa anda yakin?')">
                                                    <i class="bx bx-trash me-1"></i> Hapus
                                                </button>
                                            </form>
                                            <?php if($service->koperasi->jasa->where('isUnggulan')->count() < 4 && !$service->isUnggulan): ?>
                                                <form action="/dashboard/koperasi-jasa/<?php echo e($service->id); ?>/unggulan"
                                                    method="post">
                                                    <?php echo method_field('put'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="isUnggulan" value="1">
                                                    <button class="dropdown-item"
                                                        onclick="return confirm('Apa anda yakin?')">
                                                        <i class="bx bx-star me-1"></i> Unggulkan
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h1 class="text-center mt-5 mb-5">Jasa not found</h1>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
</section>
<?php /**PATH D:\webx\web-umkm\resources\views/dashboard/components/koperasi-jasa.blade.php ENDPATH**/ ?>