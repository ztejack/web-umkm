<!-- ======= Header ======= -->
<header id="header" class="fixed-top <?php echo e(Request::is('home') ? '' : 'header-search'); ?>">
    <div class="container d-flex align-items-center">

        <h1 class="logo me-auto">
            <a href="/"><?php echo e($website[0]->sitename); ?></a>
        </h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

        <nav id="navbar" class="navbar">
            <ul>
                <?php if(Request::is('/')): ?>
                    <li><a class="nav-link scrollto <?php echo e(Request::is('home') ? 'active' : ''); ?>" href="#hero">Home</a>
                    </li>
                    <li><a class="nav-link scrollto" href="/agenda">Agenda</a></li>
                    <li><a class="nav-link scrollto" href="#about">About</a></li>
                    <li><a class="nav-link scrollto" href="/search/umkm">UMKM & Koperasi</a></li>
                    <li><a class="nav-link scrollto" href="/pegawai">Kepegawaian</a></li>
                    <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
                <?php else: ?>
                    <li><a class="nav-link scrollto " href="/">Home</a></li>
                    <li><a class="nav-link scrollto <?php echo e(Request::is('agenda*') ? 'active' : ''); ?>"
                            href="/agenda">Agenda</a></li>
                    <li><a class="nav-link scrollto" href="/#about">About</a></li>
                    <li><a class="nav-link scrollto <?php echo e(Request::is('search*') ? 'active' : ''); ?>"
                            href="/search/umkm">UMKM
                            & Koperasi</a></li>
                    <li><a class="nav-link scrollto <?php echo e(Request::is('pegawai*') ? 'active' : ''); ?>"
                            href="/pegawai">Kepegawaian</a></li>
                    <li><a class="nav-link scrollto " href="/#contact">Contact</a></li>
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                    <li class="dropdown">
                        <a href="#">
                            <span><?php echo e(Auth::user()->username); ?></span>
                            <i class='bi bi-chevron-down bx-burst'></i>
                        </a>
                        <ul>

                            <li><a href="/dashboard">
                                    Dashboard
                                </a>
                            </li>
                            <li><a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                            </li>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </ul>
                    </li>
                <?php else: ?>
                    <li>
                        <a class="getstarted" href="/login">Login</a>
                    </li>
                <?php endif; ?>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav>
        <!-- .navbar -->
    </div>
</header>
<!-- End Header -->
<?php /**PATH D:\webx\web-umkm\resources\views/components/navbar.blade.php ENDPATH**/ ?>