
<?php $__env->startSection('content'); ?>
    <main id="main">
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="container">
                <ol>
                    <li><a href="/">Home</a></li>
                    <li>Agenda</li>
                </ol>
                <h2>Agenda Dinas</h2>
                <div id="search-p">
                    <!-- ======= Search Section ======= -->
                    <section id="search" class="why-us section-bg">
                        <div class="container" data-aos="fade-up">
                            <div
                                class="section-title <?php echo e(Request::is('search*') ? 'd-none' : ''); ?><?php echo e(Request::is('agenda*') ? 'd-none' : ''); ?>">
                                <h2>Search</h2>
                            </div>
                            <div class="row-content">
                                <div class="row justify-content-center">
                                    <div class="col-lg-8 row">
                                        <p>Cari Agenda Dinas</p>
                                        <div id="input-g"class="input-group">
                                            <form action="/agenda" method="get" id="formSearch"
                                                class="row p-0 input-group">
                                                <input type="text" class="col-10 form-control shad-none" name="search"
                                                    value="<?php echo e(request('search')); ?>">
                                                <button class="col-2 form-control shad-none" type="submit">
                                                    <i class="bx bx-search"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                <section id="employee" class="employee  py-0">
                    <div class="container" data-aos="fade-up">
                        <div class="row">
                            <?php $__currentLoopData = $agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-6 my-2 p-2">
                                    <a href="agenda/<?php echo e($agenda->id); ?>" class="agenda-card">
                                        <div class="member d-flex align-items-start p-4" data-aos="zoom-in"
                                            data-aos-delay="100">
                                            <div class="pic rounded">
                                                <?php if($agenda->image): ?>
                                                    <img src="<?php echo e(asset('storage/' . $agenda->image)); ?>" class="img-fluid"
                                                        alt="">
                                                <?php else: ?>
                                                    <img src="img\temp\agenda-temp.png" class="img-fluid" alt="">
                                                <?php endif; ?>
                                            </div>
                                            <div class="member-info col-lg ps-2">
                                                <h4><?php echo e($agenda->name); ?></h4>
                                                <small><?php echo e(date('d F Y', strtotime($agenda->date))); ?></small>
                                                <span><?php echo e($agenda->location); ?></span>
                                                <?php echo Str::limit($agenda->content, 110); ?>

                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </section>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webx\web-umkm\resources\views/pages/agenda/index.blade.php ENDPATH**/ ?>