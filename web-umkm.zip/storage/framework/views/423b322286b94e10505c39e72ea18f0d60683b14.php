

<?php $__env->startSection('content'); ?>
    <main id="main">
        <section id="identity" class="identity">
            <div class="container">
                <div class="row">
                    <div class="col-4 position-relative">
                        <div class="position-absolute top-50 translate-middle-img">
                            <div class="image-identity">
                                <?php if($koperasi->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $koperasi->image)); ?>" alt="user-avatar"
                                        class="img-fluid" id="uploadedAvatar">
                                <?php else: ?>
                                    <img src="/img/temp/store-temp.png" alt="user-avatar" class="img-fluid"
                                        id="uploadedAvatar">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="describ col-8">
                        <h2><?php echo e($koperasi->name); ?></h2>
                        <p><?php echo $koperasi->description; ?></p>
                        <div class="row">
                            <span class="col-6">
                                <i class="bi bi-upc-scan"></i> NIK : <span class="val"><?php echo e($koperasi->nik); ?></span>
                            </span>
                            <span class="col-6">
                                <i class="bx ri-service-line"></i> Koperasi <span
                                    class="val"><?php echo e($koperasi->categoryKoperasi->category); ?></span>
                            </span>
                        </div>
                        <div class="row">
                            <span class="col-6"><i class="bi bi-person"></i> Pemilik : <span
                                    class="val"><?php echo e($koperasi->user->name); ?></span>
                            </span>
                            <span class="col-6"><i class="bi bi-telephone"></i> No HP :
                                <span class="val"><?php echo e($koperasi->user->phonenumber); ?></span></span>
                        </div>
                        <div class="row">
                            <span class="col-6"><i class="bx bx-group"></i> Member :
                                <span class="val">
                                    <?php if($koperasi->member): ?>
                                        <?php echo e($koperasi->member); ?>

                                    <?php else: ?>
                                        -
                                    <?php endif; ?>

                                </span>
                            </span>
                            <span class="col-6"><i class="bx bxs-group"></i> Karyawan :
                                <span class="val">
                                    <?php if($koperasi->employee): ?>
                                        <?php echo e($koperasi->employee); ?>

                                    <?php else: ?>
                                        -
                                    <?php endif; ?>

                                </span>
                            </span>
                        </div>
                        <div class="row">
                            <span><i class="bi bi-geo-alt"></i> Alamat: <span
                                    class="val"><?php echo e($koperasi->address); ?></span></span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="product" class="product">
            <?php if($koperasi->jasa->count()): ?>
                <div class="container" data-aos="fade-up" data-aos-delay="200">
                    <div class="row">

                        <div class="row prod-container col-12">
                            <div class="row jdl p-0">
                                <div class="col-6 justify-conten-right">
                                    <h5>Layanan Koperasi</h5>
                                </div>
                            </div>
                            <?php $__currentLoopData = $koperasi->jasa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-xl-3 col-md-6 d-flex align-items-stretch my-4 mt-xl-0 rounded"
                                    data-aos="zoom-in" data-aos-delay="100">

                                    <div class="product-card p-4">
                                        <?php if($service->image): ?>
                                            <img src="<?php echo e(asset('storage/' . $service->image)); ?>" alt="user-avatar"
                                                class="img-fluid" id="uploadedAvatar">
                                        <?php else: ?>
                                            <img src="/img/temp/service-temp.png" alt="user-avatar" class="img-fluid"
                                                id="uploadedAvatar">
                                        <?php endif; ?>
                                        <h4><?php echo e(Str::limit($service->name, 15, '...')); ?></h4>
                                        <div class="row">
                                            <span class="col-12 d-flex">
                                                <i class="bx bx-chart bx-burst my-auto"></i>
                                                &nbsp;
                                                <span class="my-auto"><?php echo e($service->service); ?></span>
                                            </span>
                                            <span class="col-12 d-flex">
                                                <i class="bx bx-donate-heart bx-burst my-auto"></i>
                                                &nbsp;
                                                <span class="my-auto"><?php echo e($service->needs); ?></span>
                                            </span>
                                            <a href="/koperasi/jasa/<?php echo e($service->slug); ?>"
                                                class="btn mt-3 col-12">Detail</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                </div>
            <?php else: ?>
                <h1 class="text-center">Not Found :(</h1>
            <?php endif; ?>

            <div class="container" data-aos="fade-up" data-aos-delay="200">
                <div class="row">
                    <?php if($koperasi->product->where('isUnggulan')->count()): ?>
                        <div class="row prod-container col-12">
                            <div class="row">
                                <div class="col-6 justify-conten-start">
                                    <h5>Product Unggulan</h5>
                                </div>

                            </div>

                            <?php $__currentLoopData = $koperasi->product->where('isUnggulan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-xl-3 col-md-6 d-flex align-items-stretch my-4 mt-xl-0 rounded"
                                    data-aos="zoom-in" data-aos-delay="100">

                                    <div class="product-card p-4">
                                        <?php if($product->image): ?>
                                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="user-avatar"
                                                class="img-fluid" id="uploadedAvatar">
                                        <?php else: ?>
                                            <img src="/img/temp/product-temp.png" alt="user-avatar" class="img-fluid"
                                                id="uploadedAvatar">
                                        <?php endif; ?>
                                        <h4><?php echo e(Str::limit($product->name, 15, '...')); ?></h4>
                                        <div class="row">
                                            <div class="col-8 row">
                                                <span class="col-12 d-flex">
                                                    <i class="bx bx-money bx-burst my-auto"></i>
                                                    <p>&nbsp;Harga</p>
                                                </span>
                                                <span class="my-auto">Rp. <?php echo number_format($product->price,0,',','.'); ?></span>
                                                <div class="my-2"></div>
                                                <span class="d-flex">
                                                    <i class='bx bx-cuboid bx-burst my-auto'></i>
                                                    <p>&nbsp;Berat</p>
                                                </span>
                                                <span class="my-auto"><?php echo e($product->weight); ?> Kg</span>
                                            </div>
                                            <div class="col-4 row justify-content-center d-flex">
                                                <span class="col-12 d-flex justify-content-center">
                                                    <i class="bx bxs-star bx-tada bx-lg my-auto"></i>
                                                </span>
                                                <span class="col-12 d-flex justify-content-center">
                                                    <h6>Unggulan</h6>
                                                </span>
                                            </div>
                                            <a href="/koperasi/product/<?php echo e($product->slug); ?>"
                                                class="btn mt-3 col-12">Detail</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                    <?php endif; ?>

                </div>

                <div class="row prod-container col-12">
                    <div class="row jdl p-0">
                        <div class="col-6 justify-conten-right">
                            <h5>Product Terbaru</h5>
                        </div>
                    </div>
                    <?php if($koperasi->product->count()): ?>
                        <?php $__currentLoopData = $koperasi->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-3 col-md-6 d-flex align-items-stretch my-4 mt-xl-0 rounded"
                                data-aos="zoom-in" data-aos-delay="100">

                                <div class="product-card p-4">
                                    <?php if($product->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="user-avatar"
                                            class="img-fluid" id="uploadedAvatar">
                                    <?php else: ?>
                                        <img src="/img/temp/product-temp.png" alt="user-avatar" class="img-fluid"
                                            id="uploadedAvatar">
                                    <?php endif; ?>
                                    <h4><?php echo e(Str::limit($product->name, 15, '...')); ?></h4>
                                    <div class="row">
                                        <span class="col-12 d-flex">
                                            <i class="bx bx-money bx-burst my-auto"></i>
                                            &nbsp;Harga &nbsp;
                                            <span class="my-auto">: Rp. <?php echo number_format($product->price,0,',','.'); ?></span>
                                        </span>
                                        <span class="col-12 d-flex">
                                            <i class='bx bx-cuboid bx-burst my-auto'></i>
                                            &nbsp;Berat &nbsp;
                                            <span class="my-auto">: <?php echo e($product->weight); ?> Kg</span>
                                        </span>
                                        <a href="/koperasi/product/<?php echo e($product->slug); ?>"
                                            class="btn mt-3 col-12">Detail</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h1 class="text-center">Koperasi ini Belum Memiliki Produk :(</h1>
                    <?php endif; ?>
                </div>

            </div>

            </div>

        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webx\web-umkm\resources\views/pages/koperasi/index.blade.php ENDPATH**/ ?>