
<?php $__env->startSection('content'); ?>
    <main id="main" class="h-100">
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="container h-100">
                <ol>
                    <li><a href="/">Home</a></li>
                    <li><a href="/agenda">Agenda</a></li>
                </ol>
                <h2>Agenda Dinas</h2>
            </div>
        </section>
        <section id="d-agendas">
            <div class="container">
                <div class="row">
                    <div class=" container-lg title-container d-flex flex-column align-items-center">
                        <h2><strong><?php echo e($agenda->name); ?></strong></h2>
                        <div class="img-container d-flex flex-column align-items-center">
                            <?php if($agenda->image): ?>
                                <img src="<?php echo e(asset('storage/' . $agenda->image)); ?>" class="img-fluid">
                            <?php else: ?>
                                <img src="/img/temp/agenda-temp.png" class="img-fluid">
                                
                            <?php endif; ?>
                        </div>
                        <div class="row  my-2 w-100">
                            <hr class="w-100 border-2 opacity-50 mb-2">
                            <div class="img-title d-flex w-100">
                                <h6 class="me-auto"><?php echo e($agenda->location); ?></h6>
                                <h6 class="ms-auto"><?php echo e(date('d F Y', strtotime($agenda->date))); ?></h6>
                            </div>
                            <hr class="w-100 border-2 opacity-50">
                        </div>
                    </div>
                    <div class="container">
                        <p><?php echo $agenda->content; ?> </p>
                    </div>
                </div>
            </div>
        </section>
        <?php echo $__env->make('components.agenda', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webx\web-umkm\resources\views/pages/agenda/detail.blade.php ENDPATH**/ ?>