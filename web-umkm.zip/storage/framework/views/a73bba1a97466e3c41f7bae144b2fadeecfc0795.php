<section id="agenda" class="employee section-bg">
    <div class="container" data-aos="fade-up">
        <div class="section-title">
            <h2>Agenda Dinas</h2>
        </div>
        <!-- Slider main container -->
        <div class="swiper">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">

                <!-- Slides -->
                <?php $__currentLoopData = $agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="swiper-slide p-2 my-2" href="/agenda/<?php echo e($agenda->id); ?>">
                        <div class=" my-4">
                            <div class="member d-flex align-items-start p-4" data-aos="zoom-in" data-aos-delay="100">
                                <div class="pic rounded">
                                    <?php if($agenda->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $agenda->image)); ?>" class="img-fluid"
                                            alt="">
                                    <?php else: ?>
                                        <img src="/img/temp/agenda-temp.png" class="img-fluid" alt="">
                                    <?php endif; ?>
                                </div>
                                <div class="member-info col-lg px-2 d-block d-sm-none ">
                                    <h4><?php echo e($agenda->name); ?></h4>
                                    <small><?php echo e(date('d F Y', strtotime($agenda->date))); ?></small>
                                    <span><?php echo e($agenda->location); ?></span>
                                </div>
                                <div class="member-info col-lg px-2 d-none d-lg-block">
                                    <h4><?php echo e($agenda->name); ?></h4>
                                    <small><?php echo e(date('d F Y', strtotime($agenda->date))); ?></small>
                                    <span><?php echo e($agenda->location); ?></span>
                                    <?php echo Str::limit($agenda->content, 110); ?>

                                </div>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- If we need pagination -->
            <div class="swiper-pagination"></div>

            <!-- If we need navigation buttons -->
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>

    </div>
    </div>
    </div>

</section>
<?php /**PATH D:\webx\web-umkm\resources\views/components/agenda.blade.php ENDPATH**/ ?>