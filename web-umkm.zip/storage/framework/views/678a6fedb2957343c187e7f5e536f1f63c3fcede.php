<div class="row py-3 mb-2">
    <div class="col-6">
        <h4 class="fw-bold">Daftar UMKM & Koperasi</h4>
    </div>

</div>

<div class="row g-4 mb-5">
    <?php $__currentLoopData = $umkms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-6">
            <div class="card h-100">
                <img class="card-img-top" src="/img/elements/2.jpg" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title fw-bold"><?php echo e($umkm->name); ?></h5>
                    <h6><?php echo e($umkm->city); ?></h6>
                    <p class="card-text"><?php echo e($umkm->product->count()); ?> Produk</p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="d-flex justify-content-center pt-3">
        <?php echo e($umkms->appends([
                'koperasis' => $koperasis->currentPage(),
            ])->links('components.paginator')); ?>

    </div>
    <?php $__currentLoopData = $koperasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $koperasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-6">
            <div class="card h-100">
                <img class="card-img-top" src="/img/elements/2.jpg" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title fw-bold"><?php echo e($koperasi->name); ?></h5>
                    <h6><?php echo e($koperasi->city); ?></h6>
                    <p class="card-text"><?php echo e($koperasi->product->count()); ?> Produk</p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="d-flex justify-content-center pt-3">
        <?php echo e($koperasis->appends([
                'umkms' => $umkms->currentPage(),
            ])->links('components.paginator')); ?>

    </div>


</div>
<?php /**PATH D:\webx\web-umkm\resources\views/dashboard/components/comp2.blade.php ENDPATH**/ ?>