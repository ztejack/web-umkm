<!-- ======= Team Section ======= -->
<section id="employee" class="employee section-bg">
    <div class="container" data-aos="fade-up">

        <div class="section-title">
            <h2>Pegawai</h2>
            <p>Data Pegawai Dinas Koperasi UMKM Lampung</p>
        </div>

        <div class="row">
            <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6 my-lg-2 my-1 px-2">
                    <div class="member align-items-start p-2 p-lg-4 d-flex" data-aos="zoom-in" data-aos-delay="100">
                        <div class="col-4 d-flex">
                            <div class="m-auto pic">
                                <?php if($pegawai->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $pegawai->image)); ?>" class="img-fluid"
                                        alt="">
                                <?php else: ?>
                                    <img src="img\temp\user-temp.png" class="img-fluid" alt="">
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="col-6 ps-lg-2 member-info">
                            <h5><?php echo e($pegawai->name); ?></h5>
                            <p><?php echo e($pegawai->classification); ?></p>
                            <span><?php echo e($pegawai->position); ?></span>
                            <p><?php echo e($pegawai->description); ?></p>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- End Team Section -->
<?php /**PATH D:\webx\web-umkm\resources\views/components/structure.blade.php ENDPATH**/ ?>