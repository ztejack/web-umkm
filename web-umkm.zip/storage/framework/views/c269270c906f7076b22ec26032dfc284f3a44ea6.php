

<?php $__env->startSection('content'); ?>
    <main id="main" class="h-100">
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="container h-100">
                <ol>
                    <li><a href="/">Home</a></li>
                    <li><a href="/">UMKM</a></li>
                    <li>Produk</li>
                </ol>
                <h2><?php echo e($product->umkm->name); ?></h2>
                <section id="identity" class="identity mt-0">
                    <div class="container">
                        <div class="row detail-prd">
                            <div class="col-4 position-relative">
                                <div class="position-absolute top-50 translate-middle-img">
                                    <div class="image-identity">
                                        <?php if($product->image): ?>
                                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="user-avatar"
                                                class="img-fluid" id="uploadedAvatar">
                                        <?php else: ?>
                                            <img src="/img/temp/product-temp.png" alt="user-avatar" class="img-fluid"
                                                id="uploadedAvatar">
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="describ col-8">
                                <h2><?php echo e($product->name); ?></h2>

                                <div class="row">
                                    <span class="col-4"><i class="bx bx-money"></i> Harga : <span
                                            class="val"><?php echo e($product->price); ?></span>
                                    </span>
                                    <span class="col-4"><i class="bx bx-cuboid"></i> Berat :
                                        <span class="val"><?php echo e($product->weight); ?></span>
                                    </span>
                                </div>
                                <div class="row">
                                    <?php if($product->where('isUnggulan')): ?>
                                        <span class="col-4">
                                            <span class="val-g">
                                                <i class="bx bxs-star bx-tada"></i> <strong>Produk Unggulan</strong>
                                            </span>
                                        </span>
                                    <?php endif; ?>
                                    <span class="col-8">
                                        <i class="bi bi-telephone"></i>
                                        Hubungi Penjual :
                                        <a href="tel:<?php echo e($product->umkm->user->phonenumber); ?>"
                                            class="val"><?php echo e($product->umkm->user->phonenumber); ?></a>

                                    </span>
                                </div>
                                <h6>Deskripsi Produk</h6>
                                <p><?php echo e($product->description); ?> </p>
                            </div>
                        </div>
                    </div>
                    <section id="product" class="product">
                        <div class="row prod-container col-12">
                            <div class="row jdl p-0">
                                <div class="col-6 justify-conten-right">
                                    <h5>Produk Lainnya</h5>
                                </div>
                            </div>
                            <?php $__currentLoopData = $product->umkm->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-xl-3 col-md-6 d-flex align-items-stretch my-4 mt-xl-0 rounded"
                                    data-aos="zoom-in" data-aos-delay="100">

                                    <div class="product-card p-4">
                                        <?php if($products->image): ?>
                                            <img src="<?php echo e(asset('storage/' . $products->image)); ?>" alt="user-avatar"
                                                class="img-fluid" id="uploadedAvatar">
                                        <?php else: ?>
                                            <img src="/img/temp/product-temp.png" alt="user-avatar" class="img-fluid"
                                                id="uploadedAvatar">
                                        <?php endif; ?>
                                        <h4><?php echo e(Str::limit($products->name, 15, '...')); ?></h4>
                                        <div class="row">
                                            <span class="col-12 d-flex">
                                                <i class="bx bx-money bx-burst my-auto"></i>
                                                &nbsp;Harga &nbsp;
                                                <span class="my-auto">: Rp. <?php echo number_format($products->price,0,',','.'); ?></span>
                                            </span>
                                            <span class="col-12 d-flex">
                                                <i class='bx bx-cuboid bx-burst my-auto'></i>
                                                &nbsp;Berat &nbsp;
                                                <span class="my-auto">: <?php echo e($products->weight); ?> Kg</span>
                                            </span>
                                            <a href="/umkm/product/<?php echo e($products->id); ?>"
                                                class="btn mt-3 col-12">Detail</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                </section>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webx\web-umkm\resources\views/pages/umkm/product.blade.php ENDPATH**/ ?>