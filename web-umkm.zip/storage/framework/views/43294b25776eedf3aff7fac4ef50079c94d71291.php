<section id="profile">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">UMKM/</span> Profile</h4>
    <div class="row g-4 mb-5">
        <div class="col-lg-12">
            <div class="card">
                <div class="row">
                    <div class="col-lg-4 p-lg-5 pl-lg-5 p-xs-2 d-flex">
                        <div class="img-container img-container-kp rounded-circle m-auto">
                            <?php if($umkm->image): ?>
                                <img src="<?php echo e(asset('storage/' . $umkm->image)); ?>" class="img-pr img-fluid img-fit">
                            <?php else: ?>
                                <img src="/img/temp/store-temp.png" class="img-pr img-fluid img-fit">
                            <?php endif; ?>
                        </div>

                    </div>
                    <div class="col--lg-8 py-5 px-5 pl-5">
                        <h3><?php echo e($umkm->name); ?></h3>
                        <div class="row">
                            <div class="col-12">
                                <h6><?php echo Str::limit($umkm->description, 200); ?></h6>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-4 col-6">
                                <h6><i class="bx bx-barcode"></i> : <?php echo e($umkm->nib); ?></h6>
                            </div>
                            <div class="col-lg-8 col-6">
                                <h6><i class="bx bx-phone"></i> : <?php echo e($umkm->phonenumber); ?></h6>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-6">
                                <h6><i class="bx bx-buildings"></i> : <?php echo e($umkm->city); ?></h6>
                            </div>
                            <div class="col-lg-8 col-6">
                                <h6><i class="bx bx-map-alt"></i> : <?php echo e($umkm->address); ?></h6>
                            </div>
                        </div>
                        <hr>
                        <a class="btn rounded-pill btn-primary"
                            href="/dashboard/umkm/<?php echo e($umkm->id); ?>/umkm-profile/edit">
                            <span class="tf-icons bx bx-edit"></span>&nbsp; Edit
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row g-4 mb-5">
        <div class="row">
            <div class="col-6">
                <h5 class="fw-bold">Produk Unggulan</h5>
            </div>
            <div class="col-6 d-flex">
                <a href="/dashboard/umkm/<?php echo e($umkm->id); ?>/umkm-product" class="btn btn-primary ms-auto">
                    <i class="tf-icons bx bx-plus"></i><span class="d-none d-sm-block">&nbsp; Tambah Produk
                        Unggulan</span>
                </a>
            </div>
        </div>
        <?php if($umkm->product->where('isUnggulan')->count()): ?>
            <?php $__currentLoopData = $umkm->product->where('isUnggulan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-3">
                    <div class="card h-100">
                        <div class="img-container img-container-prd card-img-top">
                            <?php if($product->image): ?>
                                <img class="" src="<?php echo e(asset('storage/' . $product->image)); ?>"
                                    alt="Card image cap">
                            <?php else: ?>
                                <img class="card-img-top" src="/img/portfolio/portfolio-7.jpg" alt="Card image cap">
                            <?php endif; ?>
                        </div>

                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->name); ?></h5>
                            <p class="card-text"><span class="text-success"><i class="bx bx-money"></i>
                                </span><?php echo e($product->price); ?></p>
                            <form action="/dashboard/umkm-product/<?php echo e($product->id); ?>/unggulan" method="post">
                                <?php echo method_field('put'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" class="btn-check" id="btncheck2" value="0" name="isUnggulan"
                                    autocomplete="off">
                                <button class="btn btn-outline-primary" for="btncheck2"
                                    onclick="return confirm('Apa anda yakin?')"><i class='bx bxl-product-hunt'></i>
                                    Hilangkan
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <h4 class="text-center">Belum ada product unggulan :)</h4>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH D:\webx\web-umkm\resources\views/dashboard/components/umkm-profile.blade.php ENDPATH**/ ?>