<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="light-style  customizer-hide">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php
        $website = DB::table('websites')->get();
    ?>

    <title><?php echo e($website[0]->title); ?> Login</title>
    <!-- CSS only -->
    <link rel="stylesheet" href="/vendor/css/pages/page-auth.css" />

    <?php echo $__env->make('configs.css-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>

    <!-- Content -->

    <div class="container-xxl">
        <div class="authentication-wrapper authentication-basic container-p-y">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>

    <!-- / Content -->

    
    <?php echo $__env->make('configs.js-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH D:\webx\web-umkm\resources\views/Layouts/login.blade.php ENDPATH**/ ?>